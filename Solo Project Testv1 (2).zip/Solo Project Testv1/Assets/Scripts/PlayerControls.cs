using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControls : MonoBehaviour
{
    public int walkspeed = 1000;
    public float jumpForce = 5;
    public float standingVelocity = 0.5f;
    private Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKey(KeyCode.W))
        {
            rb.AddForce(Vector3.forward * walkspeed * Time.deltaTime, ForceMode.Acceleration);
        }
        if (Input.GetKey(KeyCode.S))
        {
            rb.AddForce(Vector3.back * walkspeed * Time.deltaTime, ForceMode.Acceleration);
        }
        if (Input.GetKey(KeyCode.D))
        {
            rb.AddForce(Vector3.right * walkspeed * Time.deltaTime, ForceMode.Acceleration);
        }
        if (Input.GetKey(KeyCode.A))
        {
            rb.AddForce(Vector3.left * walkspeed * Time.deltaTime, ForceMode.Acceleration);
        }
        if (Input.GetKeyDown(KeyCode.Space) && rb.velocity.y <= standingVelocity && rb.velocity.y >= -standingVelocity)
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        
    }
}
