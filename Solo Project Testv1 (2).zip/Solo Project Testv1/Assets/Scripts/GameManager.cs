using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static bool Green = false;
    public static bool Red = false;
    public static bool Brown = false;
    public static bool Yellow = false;

    public Material GreenMaterial;
    public Material YellowMaterial;
    public Material BrownMaterial;

    public Color brown;


    public static bool inLevel = false;
    
    // Start is called before the first frame update
    void Start()
    {
        inLevel = false;
    }

    // Update is called once per frame
    void Update()
    {
        DetectColour();
    }
    public void DetectColour()
    {
        if (Green)
        {
            GreenMaterial.color = Color.green;
        }
        else
        {
            GreenMaterial.color = Color.grey;
        }
        if (Yellow)
        {
            YellowMaterial.color = Color.yellow;
        }
        else
        {
            YellowMaterial.color = Color.grey;
        }
        if (Brown)
        {
            BrownMaterial.color = brown;
        }
        else
        {
            BrownMaterial.color = Color.grey;
        }
        if (Input.GetKeyDown(KeyCode.Minus))
        {
            Green = true;
            Brown = true;
            Yellow = true;
        }
    }
}
