# ![Merge Objects icon](images/icons/Object_Merge.png) Merge Objects

The __Merge Objects__ tool merges two or more selected ProBuilder GameObjects into a single ProBuilder GameObject. 

> **Warning:** If you merge two objects that intersect, the new object might have overlapping UVs.

